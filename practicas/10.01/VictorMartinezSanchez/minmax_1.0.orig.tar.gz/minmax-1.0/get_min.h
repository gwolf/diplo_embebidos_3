
#ifndef TAM
#define TAM 17
#endif

void *getMin(void *arg);
