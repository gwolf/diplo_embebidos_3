
#ifndef TAM
#define TAM 17
#endif

void *getMax(void *arg);
