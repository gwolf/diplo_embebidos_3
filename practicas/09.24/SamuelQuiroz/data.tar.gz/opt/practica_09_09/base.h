int multiplicar(int a, int b);
