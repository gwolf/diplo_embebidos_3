#include<stdio.h>
#include"base.h"

int multiplicar(int a, int b)
{
	int res= a*b;
	return(res);
}
