#ifndef SERIAL_H
#define SERIAL_H

#include <termios.h>

int serial_open			( char *, speed_t );

#endif
