from distutils.core import setup
setup(name='apollo',
      version='1.0',
      py_modules=['conf_accM','constantes','faa','lib_m8x8','prueba_01'],
)
