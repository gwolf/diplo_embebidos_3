#ifndef CONSTANTS_H
#define CONSTANTS_H

PyObject *high;
PyObject *low;
PyObject *input;
PyObject *output;
PyObject *alt0;
PyObject *pud_off;
PyObject *pud_up;
PyObject *pud_down;
PyObject *rising_edge;
PyObject *falling_edge;
PyObject *both_edge;
PyObject *version;

void define_constants(PyObject *module);

#endif
