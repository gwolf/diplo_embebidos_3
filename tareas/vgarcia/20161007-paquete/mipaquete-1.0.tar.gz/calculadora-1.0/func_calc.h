int suma (int a, int b) ;
int resta (int a, int b) ;
int mult (int a, int b) ;
int divi (int a, int b) ;
